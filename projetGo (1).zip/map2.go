// Project CSI2120/CSI2520 
// Winter 2022
// Robert Laganiere, uottawa.ca
// version 1.2

//Nom et prénoms étudiant: DIOME Aïssatou Kangou
//ID: 300139476

package main

import "fmt"
import "time"
import "runtime"
import "os"
import "io"
import "strconv"
import "encoding/csv"
import "math"
import "sync"

type GPScoord struct {

    lat float64
	long float64
}

type LabelledGPScoord struct {
    GPScoord
	ID int     // point ID
	Label int  // cluster ID
}

const N int=4
const MinPts int=5
const eps float64= 0.0003
const filename string="yellow_tripdata_2009-01-15_9h_21h_clean.csv"
const VRAI= true;
const FAUX= false;


func main() {
	jobs := make(chan []LabelledGPScoord, N)
	
	// mutex for synchronisation
	var mutex sync.WaitGroup
	
	go consome(jobs, &mutex) 


    start := time.Now(); 

    gps, minPt, maxPt := readCSVFile(filename)
	fmt.Printf("Number of points: %d\n", len(gps))
	
	minPt = GPScoord{40.7, -74.}
	maxPt = GPScoord{40.8, -73.93}
	
	// geographical limits
	fmt.Printf("SW:(%f , %f)\n", minPt.lat, minPt.long)
	fmt.Printf("NE:(%f , %f) \n\n", maxPt.lat, maxPt.long)
	
	// Parallel DBSCAN STEP 1.
	incx := (maxPt.long-minPt.long)/float64(N)
	incy := (maxPt.lat-minPt.lat)/float64(N)
	
	var grid [N][N][]LabelledGPScoord  // a grid of GPScoord slices
	
	// Create the partition
	// triple loop! not very efficient, but easier to understand
	
	partitionSize:=0
    for j:=0; j<N; j++ {
        for i:=0; i<N; i++ {
		
		    for _, pt := range gps {
			
			    // is it inside the expanded grid cell
			    if (pt.long >= minPt.long+float64(i)*incx-eps) && (pt.long < minPt.long+float64(i+1)*incx+eps) && (pt.lat >= minPt.lat+float64(j)*incy-eps) && (pt.lat < minPt.lat+float64(j+1)*incy+eps) {
				
                    grid[i][j]= append(grid[i][j], pt) // add the point to this slide
					partitionSize++;
					jobs <- grid[i][j]
		            time.Sleep(time.Second) // wasting time
	}
	}
}
}
	close(jobs)
                				
	
	// ***
	// This is the non-concurrent procedural version
	// It should be replaced by a producer thread that produces jobs (partition to be clustered)
	// And by consumer threads that clusters partitions
    for j:=0; j<N; j++ {
        for i:=0; i<N; i++ {
		
		    DBscan(grid[i][j], MinPts, eps, i*10000000+j*1000000)
		}
	}

	
	// Parallel DBSCAN STEP 2.
	// Apply DBSCAN on each partition
	
	
	
	// Parallel DBSCAN step 3.
	// merge clusters
	// *DO NOT PROGRAM THIS STEP
	
	end := time.Now();
    fmt.Printf("\nExecution time: %s of %d points\n", end.Sub(start), partitionSize)
    fmt.Printf("Number of CPUs: %d", runtime.NumCPU())
    // wait for consumers to terminate
	mutex.Wait()
}

//Fonction consomateur afin d'appliquer notre DBScan sur chaque partion

	func consome (jobs chan []LabelledGPScoord , done *sync.WaitGroup) {
		var grid [N][N][]LabelledGPScoord  // a grid of GPScoord slices

	for k:=0; k<N; k++{
		for l:=0; l<N; l++ {

		if k!=N {
			DBscan(grid[k][l],MinPts,eps,k*10000000+l*100000);
			time.Sleep(4 * time.Second) // wasting time

		} else {
			fmt.Println("done!")
			done.Done()
			return
		}
	}
}
}

//Trouve les voisins d'un tableau labelledGPScoord donné
func trouveVoisins(coord LabelledGPScoord, coords []LabelledGPScoord, eps float64) []LabelledGPScoord {
	cobail := make([]LabelledGPScoord, 0)
	for _, item := range coords {
			g:= distanceCoord(item,coord)

		if coord.Label != item.Label && g<=eps {
			cobail = append(cobail, item) 
		}  
	}
	return cobail
} 

//fonction nous permettant de grouper nos points sans groupe c'est à dire fusionner
func grouper(premierG []LabelledGPScoord, deuxiemG []LabelledGPScoord) []LabelledGPScoord {
	ensemble := make(map[string]LabelledGPScoord)
	
	for _, ittem := range premierG {
		ensemble[strconv.Itoa(ittem.ID)] = ittem
	}
	for _, iem := range deuxiemG {
		ensemble[strconv.Itoa(iem.ID)] = iem
	}

	result := make([]LabelledGPScoord, 0)
	for _, val := range ensemble {
		result = append(result, val)
	}

	return result
}

//fonction qui nous permet d'élargir notre groupe de points
func elargeGroupe(labe []LabelledGPScoord, neighbours []LabelledGPScoord, visited map[string]bool, minPts int, eps float64) []LabelledGPScoord {
	cobail := make([]LabelledGPScoord, len(neighbours))
	copy(cobail, neighbours)
	for _, coord := range cobail {
		coordActuel, vu := visited[strconv.Itoa(coord.ID)]
		if !vu {
			neighboursActuel := trouveVoisins(coord, cobail, eps)
			if len(neighboursActuel)+1 >= minPts {
				visited[strconv.Itoa(coord.ID)] = VRAI
				labe = grouper(labe, neighboursActuel)
			}
		}

		if vu && coordActuel == FAUX {
			visited[strconv.Itoa(coord.ID)] = VRAI
			labe = append(labe, coord)
		}
	}

	return labe
}


// Applies DBSCAN algorithm on LabelledGPScoord points
// LabelledGPScoord: the slice of LabelledGPScoord points
// MinPts, eps: parameters for the DBSCAN algorithm
// offset: label of first cluster (also used to identify the cluster)
// returns number of clusters found
func DBscan(coords []LabelledGPScoord, MinPts int, eps float64, offset int) (nclusters int) {

   clusters := make([][]LabelledGPScoord, offset)
	visted := map[string]bool{}
	for _, pt := range coords {
		voisins := trouveVoisins(pt, coords, eps)
		if len(voisins)+1 >= MinPts {
			visted[strconv.Itoa(pt.ID)] = VRAI
			tableau := make([] LabelledGPScoord, offset+1)
			tableau[0] = pt
			tableau = elargeGroupe(tableau, voisins, visted, MinPts, eps)

			if len(tableau) >= MinPts {
				clusters = append(clusters, tableau)
			}
		} else {
			visted[strconv.Itoa(pt.ID)] = FAUX
		}
		nclusters++;
	}


   
   // End of DBscan function
   // Printing the result (do not remove)
   fmt.Printf("Partition %10d : [%4d,%6d]\n", offset, nclusters, len(coords))
   
   return nclusters
}

// reads a csv file of trip records and returns a slice of the LabelledGPScoord of the pickup locations  
// and the minimum and maximum GPS coordinates
func readCSVFile(filename string) (coords []LabelledGPScoord, minPt GPScoord, maxPt GPScoord) {

    coords= make([]LabelledGPScoord, 0, 5000)

    // open csv file
    src, err := os.Open(filename)
	defer src.Close()
    if err != nil {
        panic("File not found...")
    }
	
	// read and skip first line
    r := csv.NewReader(src)
    record, err := r.Read()
    if err != nil {
        panic("Empty file...")
    }

    minPt.long = 1000000.
    minPt.lat = 1000000.
    maxPt.long = -1000000.
    maxPt.lat = -1000000.
	
	var n int=0
	
    for {
        // read line
        record, err = r.Read()

        // end of file?
        if err == io.EOF {
            break
        }

        if err != nil {
             panic("Invalid file format...")
        }
		
		// get lattitude
		lat, err := strconv.ParseFloat(record[9], 64)
        if err != nil {
             panic("Data format error (lat)...")
        }

        // is corner point?
		if lat>maxPt.lat {
		    maxPt.lat= lat
		}		
		if lat<minPt.lat {
		    minPt.lat= lat
		}
		
		// get longitude
		long, err := strconv.ParseFloat(record[8], 64)
        if err != nil {
             panic("Data format error (long)...")
        }
		
        // is corner point?
		if long>maxPt.long {
		    maxPt.long= long
		}
		
		if long<minPt.long {
		    minPt.long= long
		}

        // add point to the slice
		n++
        pt:= GPScoord{lat,long}
        coords= append(coords, LabelledGPScoord{pt,n,0})
    }

    return coords, minPt,maxPt
}
//Calcule la distance entre deux points
func distanceCoord(x LabelledGPScoord, y LabelledGPScoord) float64{
	a:= x.GPScoord;
	b:= x.GPScoord;
	i:=math.Pow(a.lat,2)
	j:=math.Pow(a.long,2 )
	k:=math.Pow(b.lat,2 )
	l:=math.Pow(b.long,2 )
	c := math.Sqrt(i+j)
	d:= math.Sqrt(k+l)
	z := math.Abs(c-d);
	return z
}

//NOTES

// Nous allons créer trois autres fonctions pour notre dbscan afin d'éviter un code 
//trop long et surchargé 
//Cela permet également d'accentuer la compréhension d'une personne étrangère
//Code inspiré de la correction du dbscan java du prof
//MANQUE DE TEMPS POUR IMPRIMER LE RESULTAT ATTENDU

//FIN NOTES



